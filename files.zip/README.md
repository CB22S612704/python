# Python Remote Desktop (DIY)

A minimal two-machine remote control tool:

- **`server.py`** — runs on the computer you want to control. Streams its
  screen and executes incoming mouse/keyboard commands.
- **`client.py`** — runs on the computer you're controlling *from*. Shows the
  remote screen in a window and forwards your mouse/keyboard input to it.

## Setup

1. Copy `server.py` to the machine to be controlled, and `client.py` to the
   machine you'll control it from.

2. Install dependencies on each side:

   On the **server** machine:
   ```
   pip install mss numpy opencv-python pyautogui
   ```

   On the **client** machine:
   ```
   pip install numpy opencv-python pynput
   ```

3. Open both files and set the **same `AUTH_TOKEN`** string in each — this is
   a simple shared-secret check so random devices on your network can't
   connect. Pick something long and random, not a real password.

4. In `client.py`, set `SERVER_HOST` to the server machine's local IP address
   (e.g. `192.168.1.42`). Find it on the server with `ipconfig` (Windows) or
   `ifconfig` / `ip addr` (macOS/Linux).

5. If the server machine has a firewall, allow inbound TCP connections on
   port `5959` (or change `PORT` in both files to something else).

## Running it

On the server machine:
```
python server.py
```

On the client machine:
```
python client.py
```

A window titled "Remote Control" will open showing the server's screen.
Click and type inside it to control the remote machine. Press **ESC** with
the window focused to disconnect.

## File read/write (console commands)

Alongside the viewer window, `client.py` opens a console prompt where you
can browse and transfer files on the remote machine:

```
list <remote_path>                 - list a folder on the remote machine
get  <remote_path> <local_path>    - download a file from remote to here
put  <local_path> <remote_path>    - upload a file from here to remote
help                                - show the command list
quit                                - disconnect and exit
```

Example:
```
> list C:\Users\mages\Desktop
> get C:\Users\mages\Desktop\notes.txt C:\Downloads\notes.txt
> put C:\Downloads\installer.exe C:\Users\mages\Desktop\installer.exe
```

There's a 200 MB per-file limit (`MAX_FILE_SIZE` in `server.py`) to avoid
accidentally loading something huge into memory — raise it if you need to.

## How it works

- Both scripts speak a tiny length-prefixed protocol over a raw TCP socket
  (4-byte big-endian length + payload).
- The server grabs the screen with `mss`, JPEG-encodes each frame with
  OpenCV, and streams frames to the client at ~15 fps.
- The client decodes and displays frames, and uses OpenCV's mouse callback
  plus `pynput`'s global keyboard listener to capture your input and send it
  back as small pickled command dictionaries, which the server replays with
  `pyautogui`.

## Security notes — please read

This is a learning/personal-use tool, not a hardened product:

- **No encryption.** Traffic (including the auth token and every keystroke)
  travels in plain text. Only use it on a network you trust — your home LAN,
  or tunneled through a VPN (Tailscale, WireGuard, SSH port forwarding) if
  you need to reach it over the internet. Don't port-forward port 5959
  directly to the public internet.
- **The auth token is a basic gate, not strong security.** It's sent in
  plain text and checked with a simple string comparison. Treat it like a
  weak password, not real authentication.
- **File access is unrestricted.** Anyone connected with the right token can
  read, overwrite, or create *any file the server process can access* on
  that machine — not sandboxed to one folder. This is intentional (you asked
  for full read/write), but it means the auth token is now the only thing
  standing between a connection and your whole filesystem. Don't run
  `server.py` as Administrator/root unless you specifically need that, and
  don't expose port 5959 to the open internet.
- **Only one controller at a time** is supported by design, to avoid two
  people fighting over the mouse — the server accepts one connection, then
  waits for the next after it disconnects.
- Only run `server.py` on machines you own or have explicit permission to
  administer, and only share the auth token with people you trust.

## Known limitations

- Keyboard key names from `pynput` are forwarded fairly literally to
  `pyautogui` — most letters, numbers, and common keys (`enter`, `space`,
  `backspace`, `shift`, `ctrl`, etc.) work, but some special keys may need
  extra mapping if you hit issues (see `KEY_MAP`-style handling you can
  extend in `client.py`/`server.py`).
- No audio, no clipboard sync, no file transfer — this only covers
  screen + mouse + keyboard.
- Screen resolution is fixed to monitor index 1 (`sct.monitors[1]`, i.e. the
  primary monitor) on the server. Multi-monitor selection would need a small
  extension.
- No reconnect/retry logic — if the connection drops, just restart
  `client.py`.
