"""
Remote Desktop Server
======================
Run this on the computer you want to CONTROL REMOTELY.

Streams the screen, executes mouse/keyboard commands, and now also
supports full file read/write access (list / download / upload) requested
by the client.

Requirements:
    pip install mss numpy opencv-python pyautogui

Usage:
    python server.py
"""
import socket
import struct
import threading
import pickle
import time
import os

import mss
import numpy as np
import cv2
import pyautogui

pyautogui.FAILSAFE = False

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------
HOST = "0.0.0.0"
PORT = 5959
AUTH_TOKEN = "change-this-secret-token"  # MUST match client.py
JPEG_QUALITY = 60
FRAME_RATE = 15
MAX_FILE_SIZE = 200 * 1024 * 1024  # 200 MB safety cap on single file transfer

screen_w, screen_h = pyautogui.size()
send_lock = threading.Lock()  # serializes all writes to the socket


# ---------------------------------------------------------------------------
# Framing helpers: every message is [4-byte length][pickled payload]
# ---------------------------------------------------------------------------
def recv_exact(conn, n):
    data = b""
    while len(data) < n:
        chunk = conn.recv(n - len(data))
        if not chunk:
            return None
        data += chunk
    return data


def recv_msg(conn):
    raw_len = recv_exact(conn, 4)
    if raw_len is None:
        return None
    length = struct.unpack(">I", raw_len)[0]
    return recv_exact(conn, length)


def safe_send(conn, obj):
    """Pickle obj and send it, protected by a lock (screen + file threads share the socket)."""
    payload = pickle.dumps(obj)
    with send_lock:
        conn.sendall(struct.pack(">I", len(payload)) + payload)


# ---------------------------------------------------------------------------
# Mouse / keyboard input execution
# ---------------------------------------------------------------------------
def handle_input(cmd):
    try:
        action = cmd.get("action")
        if action == "move":
            pyautogui.moveTo(cmd["x"], cmd["y"], _pause=False)
        elif action == "mousedown":
            pyautogui.mouseDown(cmd["x"], cmd["y"], button=cmd.get("button", "left"), _pause=False)
        elif action == "mouseup":
            pyautogui.mouseUp(cmd["x"], cmd["y"], button=cmd.get("button", "left"), _pause=False)
        elif action == "scroll":
            pyautogui.scroll(cmd["amount"], _pause=False)
        elif action == "keydown":
            pyautogui.keyDown(cmd["key"], _pause=False)
        elif action == "keyup":
            pyautogui.keyUp(cmd["key"], _pause=False)
        elif action == "type":
            pyautogui.typewrite(cmd["text"], _pause=False)
        elif action == "hotkey":
            pyautogui.hotkey(*cmd["keys"])
    except Exception as e:
        print(f"[input error] {e}")


# ---------------------------------------------------------------------------
# File read / write handling
# ---------------------------------------------------------------------------
def list_dir(path):
    entries = []
    for name in sorted(os.listdir(path)):
        full = os.path.join(path, name)
        try:
            is_dir = os.path.isdir(full)
            size = os.path.getsize(full) if not is_dir else 0
        except OSError:
            is_dir, size = False, 0
        entries.append({"name": name, "is_dir": is_dir, "size": size})
    return entries


def handle_file_action(cmd, conn):
    action = cmd.get("action")

    if action == "list_dir":
        path = cmd["path"]
        try:
            entries = list_dir(path)
            safe_send(conn, {"type": "dir_listing", "path": path, "entries": entries, "error": None})
        except Exception as e:
            safe_send(conn, {"type": "dir_listing", "path": path, "entries": [], "error": str(e)})
        return True

    if action == "download":
        path = cmd["path"]
        try:
            size = os.path.getsize(path)
            if size > MAX_FILE_SIZE:
                raise ValueError(f"File too large ({size} bytes, limit {MAX_FILE_SIZE})")
            with open(path, "rb") as f:
                data = f.read()
            safe_send(conn, {"type": "file_data", "path": path, "data": data, "error": None})
        except Exception as e:
            safe_send(conn, {"type": "file_data", "path": path, "data": None, "error": str(e)})
        return True

    if action == "upload":
        path = cmd["path"]
        try:
            data = cmd["data"]
            if len(data) > MAX_FILE_SIZE:
                raise ValueError("File too large")
            os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
            with open(path, "wb") as f:
                f.write(data)
            safe_send(conn, {"type": "upload_ack", "path": path, "error": None})
        except Exception as e:
            safe_send(conn, {"type": "upload_ack", "path": path, "error": str(e)})
        return True

    return False  # not a file action


def control_listener(conn):
    """Blocks, reading commands from the client: mouse/keyboard input or file actions."""
    while True:
        data = recv_msg(conn)
        if data is None:
            break
        try:
            cmd = pickle.loads(data)
            if not handle_file_action(cmd, conn):
                handle_input(cmd)
        except Exception as e:
            print(f"[control error] {e}")


def screen_streamer(conn):
    """Background thread: pushes JPEG screen frames to the client."""
    interval = 1.0 / FRAME_RATE
    with mss.mss() as sct:
        monitor = sct.monitors[1]
        while True:
            start = time.time()
            try:
                img = np.array(sct.grab(monitor))
                img = cv2.cvtColor(img, cv2.COLOR_BGRA2BGR)
                ok, buf = cv2.imencode(".jpg", img, [cv2.IMWRITE_JPEG_QUALITY, JPEG_QUALITY])
                if not ok:
                    continue
                safe_send(conn, {"type": "frame", "data": buf.tobytes()})
            except (BrokenPipeError, ConnectionResetError, OSError):
                break
            elapsed = time.time() - start
            if elapsed < interval:
                time.sleep(interval - elapsed)


# ---------------------------------------------------------------------------
# Connection handling
# ---------------------------------------------------------------------------
def authenticate(conn) -> bool:
    token = recv_msg(conn)
    if token is None:
        return False
    return token.decode("utf-8", errors="ignore") == AUTH_TOKEN


def handle_client(conn, addr):
    print(f"[+] Connection from {addr}")
    if not authenticate(conn):
        print(f"[-] Auth failed for {addr}, closing connection.")
        conn.close()
        return

    safe_send(conn, {"type": "info", "screen_w": screen_w, "screen_h": screen_h})

    t_stream = threading.Thread(target=screen_streamer, args=(conn,), daemon=True)
    t_stream.start()

    control_listener(conn)
    print(f"[-] Connection closed: {addr}")


def main():
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server.bind((HOST, PORT))
    server.listen(1)
    print(f"Remote control server listening on {HOST}:{PORT}")
    print(f"Local screen size: {screen_w}x{screen_h}")
    print("Waiting for a client to connect...")

    while True:
        conn, addr = server.accept()
        handle_client(conn, addr)


if __name__ == "__main__":
    main()
