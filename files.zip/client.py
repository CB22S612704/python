"""
Remote Desktop Client
======================
Run this on the computer you want to control FROM.

Shows the remote screen, forwards mouse/keyboard input, and now also lets
you list/download/upload files on the remote machine from a console prompt
that runs alongside the viewer window.

Requirements:
    pip install numpy opencv-python pynput

Usage:
    1. Edit SERVER_HOST below to the target machine's IP address.
    2. python client.py
    3. Click inside the window to control the remote mouse. Type in this
       console to use file commands (see HELP_TEXT below). ESC in the
       viewer window quits.
"""
import socket
import struct
import threading
import pickle
import queue
import os

import numpy as np
import cv2

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------
SERVER_HOST = "192.168.1.100"            # <-- CHANGE to the server machine's IP
SERVER_PORT = 5959
AUTH_TOKEN = "change-this-secret-token"  # MUST match server.py

WINDOW_NAME = "Remote Control (ESC to quit)"
display_w, display_h = 1280, 720
remote_w, remote_h = 1920, 1080          # overwritten once connected

send_lock = threading.Lock()
response_queue = queue.Queue()           # file-action responses land here

HELP_TEXT = """
File commands (type here in the console, then press Enter):
  list <remote_path>                 - list a folder on the remote machine
  get  <remote_path> <local_path>    - download a file from remote to here
  put  <local_path> <remote_path>    - upload a file from here to remote
  help                                - show this message
  quit                                - disconnect and exit
"""


# ---------------------------------------------------------------------------
# Framing helpers (must match server.py)
# ---------------------------------------------------------------------------
def recv_exact(sock, n):
    data = b""
    while len(data) < n:
        chunk = sock.recv(n - len(data))
        if not chunk:
            return None
        data += chunk
    return data


def recv_msg(sock):
    raw_len = recv_exact(sock, 4)
    if raw_len is None:
        return None
    length = struct.unpack(">I", raw_len)[0]
    return recv_exact(sock, length)


def safe_send(sock, obj):
    payload = pickle.dumps(obj)
    with send_lock:
        sock.sendall(struct.pack(">I", len(payload)) + payload)


# ---------------------------------------------------------------------------
# Mouse handling
# ---------------------------------------------------------------------------
def to_remote_coords(x, y):
    rx = int(x * remote_w / display_w)
    ry = int(y * remote_h / display_h)
    return rx, ry


def mouse_callback(event, x, y, flags, param, sock):
    rx, ry = to_remote_coords(x, y)
    cmd = None
    if event == cv2.EVENT_MOUSEMOVE:
        cmd = {"action": "move", "x": rx, "y": ry}
    elif event == cv2.EVENT_LBUTTONDOWN:
        cmd = {"action": "mousedown", "x": rx, "y": ry, "button": "left"}
    elif event == cv2.EVENT_LBUTTONUP:
        cmd = {"action": "mouseup", "x": rx, "y": ry, "button": "left"}
    elif event == cv2.EVENT_RBUTTONDOWN:
        cmd = {"action": "mousedown", "x": rx, "y": ry, "button": "right"}
    elif event == cv2.EVENT_RBUTTONUP:
        cmd = {"action": "mouseup", "x": rx, "y": ry, "button": "right"}
    elif event == cv2.EVENT_MOUSEWHEEL:
        amount = 50 if flags > 0 else -50
        cmd = {"action": "scroll", "amount": amount}

    if cmd:
        try:
            safe_send(sock, cmd)
        except OSError:
            pass


# ---------------------------------------------------------------------------
# Keyboard handling (system-wide capture via pynput)
# ---------------------------------------------------------------------------
def keyboard_sender(sock, stop_event):
    from pynput import keyboard

    def key_name(key):
        try:
            return key.char
        except AttributeError:
            return str(key).replace("Key.", "")

    def on_press(key):
        if stop_event.is_set():
            return False
        try:
            safe_send(sock, {"action": "keydown", "key": key_name(key)})
        except OSError:
            return False

    def on_release(key):
        if stop_event.is_set():
            return False
        try:
            safe_send(sock, {"action": "keyup", "key": key_name(key)})
        except OSError:
            return False

    with keyboard.Listener(on_press=on_press, on_release=on_release) as listener:
        listener.join()


# ---------------------------------------------------------------------------
# File command console (runs in its own thread)
# ---------------------------------------------------------------------------
def console_loop(sock, stop_event):
    print(HELP_TEXT)
    while not stop_event.is_set():
        try:
            line = input("> ").strip()
        except EOFError:
            break
        if not line:
            continue
        parts = line.split(maxsplit=2)
        cmd_word = parts[0].lower()

        if cmd_word == "help":
            print(HELP_TEXT)

        elif cmd_word == "quit":
            stop_event.set()
            break

        elif cmd_word == "list" and len(parts) >= 2:
            safe_send(sock, {"action": "list_dir", "path": parts[1]})
            resp = _wait_for(response_queue, "dir_listing", timeout=15)
            if resp is None:
                print("No response (timed out).")
            elif resp["error"]:
                print(f"Error: {resp['error']}")
            else:
                for e in resp["entries"]:
                    tag = "<DIR>" if e["is_dir"] else f"{e['size']} bytes"
                    print(f"  {e['name']:40s} {tag}")

        elif cmd_word == "get" and len(parts) >= 3:
            remote_path, local_path = parts[1], parts[2]
            safe_send(sock, {"action": "download", "path": remote_path})
            resp = _wait_for(response_queue, "file_data", timeout=60)
            if resp is None:
                print("No response (timed out).")
            elif resp["error"]:
                print(f"Error: {resp['error']}")
            else:
                with open(local_path, "wb") as f:
                    f.write(resp["data"])
                print(f"Saved {len(resp['data'])} bytes to {local_path}")

        elif cmd_word == "put" and len(parts) >= 3:
            local_path, remote_path = parts[1], parts[2]
            if not os.path.isfile(local_path):
                print(f"Local file not found: {local_path}")
                continue
            with open(local_path, "rb") as f:
                data = f.read()
            safe_send(sock, {"action": "upload", "path": remote_path, "data": data})
            resp = _wait_for(response_queue, "upload_ack", timeout=60)
            if resp is None:
                print("No response (timed out).")
            elif resp["error"]:
                print(f"Error: {resp['error']}")
            else:
                print(f"Uploaded {len(data)} bytes to {remote_path}")

        else:
            print("Unrecognized command. Type 'help' for the list of commands.")


def _wait_for(q, msg_type, timeout):
    """Pull messages off the response queue until we see the type we want."""
    try:
        return q.get(timeout=timeout)
    except queue.Empty:
        return None


# ---------------------------------------------------------------------------
# Main loop: receive & display screen frames, route non-frame messages
# ---------------------------------------------------------------------------
def main():
    global remote_w, remote_h

    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.connect((SERVER_HOST, SERVER_PORT))
    safe_send_raw_token(sock)

    info = _recv_dict(sock)
    if info is None or info.get("type") != "info":
        print("Authentication failed or server closed the connection.")
        return
    remote_w, remote_h = info["screen_w"], info["screen_h"]
    print(f"Connected. Remote screen: {remote_w}x{remote_h}")

    cv2.namedWindow(WINDOW_NAME, cv2.WINDOW_NORMAL)
    cv2.resizeWindow(WINDOW_NAME, display_w, display_h)
    cv2.setMouseCallback(WINDOW_NAME, lambda *a: mouse_callback(*a, sock=sock))

    stop_event = threading.Event()
    threading.Thread(target=keyboard_sender, args=(sock, stop_event), daemon=True).start()
    threading.Thread(target=console_loop, args=(sock, stop_event), daemon=True).start()

    try:
        while not stop_event.is_set():
            msg = _recv_dict(sock)
            if msg is None:
                print("Server closed the connection.")
                break

            msg_type = msg.get("type")
            if msg_type == "frame":
                frame = cv2.imdecode(np.frombuffer(msg["data"], np.uint8), cv2.IMREAD_COLOR)
                if frame is None:
                    continue
                frame = cv2.resize(frame, (display_w, display_h))
                cv2.imshow(WINDOW_NAME, frame)
                if cv2.waitKey(1) & 0xFF == 27:  # ESC
                    break
            else:
                # dir_listing / file_data / upload_ack -> hand to console thread
                response_queue.put(msg)
    finally:
        stop_event.set()
        sock.close()
        cv2.destroyAllWindows()


def safe_send_raw_token(sock):
    token = AUTH_TOKEN.encode("utf-8")
    sock.sendall(struct.pack(">I", len(token)) + token)


def _recv_dict(sock):
    raw = recv_msg(sock)
    if raw is None:
        return None
    return pickle.loads(raw)


if __name__ == "__main__":
    main()
